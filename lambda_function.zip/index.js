exports.handler = async (event) => {
  try {
    // Log the incoming event for debugging
    console.log("Received event:", JSON.stringify(event));

    // Extract the HTTP method from the event
    const method = event.httpMethod;

    // Check if the HTTP method is OPTIONS for CORS preflight request
    if (method === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*', // Allow any origin, or specify your domain
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS', // Allowed HTTP methods
          'Access-Control-Allow-Headers': 'Content-Type, Authorization' // Allowed headers
        },
        body: "" // Use an empty string instead of null
      };
    }

    // Default response for other HTTP methods (GET, POST, etc.)
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*' // Allow any origin, or specify your domain
      },
      body: JSON.stringify({ message: 'Hello from Lambda!' })
    };

  } catch (error) {
    // Log the error and return a 500 status code
    console.error("Error processing request:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' })
    };
  }
};
